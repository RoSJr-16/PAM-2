import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import axios from 'axios';

const API_URL = 'http://10.0.2.2:3000'; // Emulador Android
// Para celular físico, troque pelo IP da sua máquina na rede, ex: http://192.168.0.10:3000

export default function App() {
  const [tab, setTab] = useState('get');
  const [clients, setClients] = useState([]);
  const [loadingGet, setLoadingGet] = useState(false);
  const [loadingPost, setLoadingPost] = useState(false);
  const [nome, setNome] = useState('');
  const [cpf, setCpf] = useState('');

  const fetchClients = async () => {
    setLoadingGet(true);
    try {
      const response = await axios.get(`${API_URL}/clients`);
      setClients(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      console.error('Erro ao buscar clientes:', error);
      Alert.alert('Erro', 'Não foi possível carregar os clientes.');
    } finally {
      setLoadingGet(false);
    }
  };

  useEffect(() => {
    if (tab === 'get') {
      fetchClients();
    }
  }, [tab]);

  const handleSalvar = async () => {
    if (!nome.trim() || !cpf.trim()) {
      Alert.alert('Atenção', 'Preencha nome e CPF.');
      return;
    }

    setLoadingPost(true);
    try {
      const response = await axios.post(`${API_URL}/inserir`, {
        nomeCliente: nome.trim(),
        cpfCliente: cpf.trim(),
      });

      if (response.status === 201) {
        Alert.alert('Sucesso', 'Cliente cadastrado com sucesso!');
        setNome('');
        setCpf('');
        setTab('get');
        fetchClients();
      }
    } catch (error) {
      console.error(error);
      Alert.alert('Erro', 'Não foi possível cadastrar o cliente.');
    } finally {
      setLoadingPost(false);
    }
  };

  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <Text style={styles.name}>{item.nomeCliente}</Text>
      <Text style={styles.details}>ID: {item.idCliente}</Text>
      <Text style={styles.details}>CPF: {item.cpfCliente}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Clientes</Text>
        <Text style={styles.subtitle}>GET e POST consumindo sua API</Text>
      </View>

      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tabButton, tab === 'get' && styles.tabButtonActive]}
          onPress={() => setTab('get')}
        >
          <Text style={[styles.tabText, tab === 'get' && styles.tabTextActive]}>Listar</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tabButton, tab === 'post' && styles.tabButtonActive]}
          onPress={() => setTab('post')}
        >
          <Text style={[styles.tabText, tab === 'post' && styles.tabTextActive]}>Cadastrar</Text>
        </TouchableOpacity>
      </View>

      {tab === 'get' ? (
        <View style={styles.flex}>
          {loadingGet ? (
            <View style={styles.center}>
              <ActivityIndicator size="large" />
            </View>
          ) : (
            <FlatList
              data={clients}
              keyExtractor={(item) => String(item.idCliente)}
              renderItem={renderItem}
              contentContainerStyle={styles.list}
              ListEmptyComponent={
                <Text style={styles.empty}>Nenhum cliente encontrado.</Text>
              }
              refreshing={loadingGet}
              onRefresh={fetchClients}
            />
          )}
        </View>
      ) : (
        <View style={styles.form}>
          <Text style={styles.label}>Nome</Text>
          <TextInput
            style={styles.input}
            placeholder="Digite o nome"
            value={nome}
            onChangeText={setNome}
          />

          <Text style={styles.label}>CPF do Cliente</Text>
          <TextInput
            style={styles.input}
            placeholder="000.000.000-00"
            keyboardType="numeric"
            value={cpf}
            onChangeText={setCpf}
          />

          <TouchableOpacity
            style={styles.button}
            onPress={handleSalvar}
            disabled={loadingPost}
          >
            {loadingPost ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>Salvar</Text>
            )}
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    paddingHorizontal: 16,
    paddingTop: 18,
  },
  header: {
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#111',
  },
  subtitle: {
    marginTop: 4,
    fontSize: 14,
    color: '#666',
  },
  tabs: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 16,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    backgroundColor: '#e6e6e6',
    alignItems: 'center',
  },
  tabButtonActive: {
    backgroundColor: '#007BFF',
  },
  tabText: {
    color: '#333',
    fontWeight: '600',
  },
  tabTextActive: {
    color: '#fff',
  },
  flex: {
    flex: 1,
  },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  list: {
    paddingBottom: 20,
  },
  card: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 10,
    marginBottom: 12,
    elevation: 2,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111',
    marginBottom: 4,
  },
  details: {
    fontSize: 14,
    color: '#666',
  },
  empty: {
    textAlign: 'center',
    color: '#666',
    marginTop: 24,
  },
  form: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
  },
  label: {
    fontSize: 16,
    marginBottom: 6,
    color: '#444',
    fontWeight: '600',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 16,
    backgroundColor: '#fafafa',
  },
  button: {
    backgroundColor: '#007BFF',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
