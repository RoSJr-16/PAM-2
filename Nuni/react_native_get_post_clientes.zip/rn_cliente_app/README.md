# App React Native - GET e POST

Projeto Expo para consumir a API Node do seu CRUD.

## API
- GET: /clients
- POST: /inserir

## Ajuste de endereço
- Emulador Android: http://10.0.2.2:3000
- Celular físico: substitua pelo IP da sua máquina na rede local
