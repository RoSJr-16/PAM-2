import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import TarefasScreen from './src/screens/TarefasScreen';
import NovaTarefaScreen from './src/screens/NovaTarefaScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Tarefas" component={TarefasScreen} />
        <Stack.Screen name="NovaTarefa" component={NovaTarefaScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
