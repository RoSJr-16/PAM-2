import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import api from '../services/api';

export default function NovaTarefaScreen() {
  const [nome, setNome] = useState('');
  const [tempo, setTempo] = useState('');
  const [relevancia, setRelevancia] = useState('');
  const [status, setStatus] = useState('');

  async function salvar() {
    await api.post('/tarefas', {
      nome_da_tarefa: nome,
      tempo,
      relevancia,
      status
    });

    Alert.alert('Sucesso', 'Tarefa cadastrada!');
  }

  return (
    <View style={styles.container}>
      <TextInput style={styles.input} placeholder="Tarefa" onChangeText={setNome} />
      <TextInput style={styles.input} placeholder="Tempo" onChangeText={setTempo} />
      <TextInput style={styles.input} placeholder="Relevância" onChangeText={setRelevancia} />
      <TextInput style={styles.input} placeholder="Status" onChangeText={setStatus} />

      <TouchableOpacity style={styles.button} onPress={salvar}>
        <Text style={{color:'#FFF'}}>Salvar</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{ flex:1, padding:20 },
  input:{
    borderWidth:1,
    borderColor:'#CCC',
    padding:12,
    borderRadius:8,
    marginBottom:15
  },
  button:{
    backgroundColor:'#2196F3',
    padding:15,
    borderRadius:8,
    alignItems:'center'
  }
});
