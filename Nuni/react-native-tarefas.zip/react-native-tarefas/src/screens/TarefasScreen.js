import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, ActivityIndicator } from 'react-native';
import api from '../services/api';

export default function TarefasScreen() {
  const [tarefas, setTarefas] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    carregar();
  }, []);

  async function carregar() {
    try {
      const response = await api.get('/tarefas');
      setTarefas(response.data);
    } finally {
      setLoading(false);
    }
  }

  if (loading) return <ActivityIndicator size="large" />;

  return (
    <FlatList
      data={tarefas}
      keyExtractor={(item) => item.id.toString()}
      renderItem={({ item }) => (
        <View style={styles.card}>
          <Text style={styles.nome}>{item.nome_da_tarefa}</Text>
          <Text>Tempo: {item.tempo}</Text>
          <Text>Relevância: {item.relevancia}</Text>
          <Text>Status: {item.status}</Text>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  card:{
    backgroundColor:'#FFF',
    padding:15,
    margin:10,
    borderRadius:10,
    elevation:4
  },
  nome:{
    fontSize:18,
    fontWeight:'bold'
  }
});
