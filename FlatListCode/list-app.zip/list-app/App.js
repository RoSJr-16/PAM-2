import {View, FlatList, StyleSheet, Text, StatusBar} from 'react-native';

const DATA = [
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    preco: '$10,99',
    desc: 'Minhoca'
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'Second Item',
    preco: '$9,99',
    desc: 'Maçã',
  },
  {

    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
    preco: '$9,99',
    desc: 'Banana',
  },
];

const produtos = [
  //nome do produto, valor, data do cadastro equantidade.
  {
    nome_produto: '',
    valor: '',
    data_cad: '',
    qtd: '',
  },
  {
    nome_produto: '',
    valor: '',
    data_cad: '',
    qtd: '',

  },
  {
    nome_produto: '',
    valor: '',
    data_cad: '',
    qtd: '',

  },
  {
    nome_produto: '',
    valor: '',
    data_cad: '',
    qtd: '',

  },
  {
    nome_produto: '',
    valor: '',
    data_cad: '',
    qtd: '',

  },
]

const Item = ({title}) => (
  <View style={styles.item}>
    <Text style={styles.title}>{title}</Text>
    <Text style={styles.title}>{preco} </Text>
    <Text style={styles.title}>{desc} </Text>
  </View>
);

export default function App(){  
return(
  <View style={styles.container}>
    <FlatList
      data={DATA}
      renderItem={({item}) => <Item title={item.title} preco={item.preco} desc={item.desc}  />}
      keyExtractor={item => item.id}
    />
  </View>
  )  
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: StatusBar.currentHeight || 0,
  },
  item: {
    backgroundColor: 'aliceblue',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },
  title: {
    fontSize: 32,
  },
});

/**
const Item = ({nome, valor, dtCadastro, qntd}) => (
  <View style={styles.item}>
    <Text style={styles.nome}>{nome}</Text>
    <Text style={styles.nome }>{valor}</Text>
    <Text style={styles.nome}>{dtCadastro}</Text>
    <Text style={styles.nome}>{qntd}</Text>
  </View>
);

export default function App(){  
return(
  <View style={styles.container}>
    <FlatList
      data={DATA}
      renderItem={({item}) => <Item nome={item.nome} valor={item.valor} dtCadastro={item.dtCadastro} qntd={item.qntd}/>}
      keyExtractor={item => item.id}
    />
  </View>
  )  
};
 */