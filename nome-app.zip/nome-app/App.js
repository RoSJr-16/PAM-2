import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <StatusBar style="auto" />

      

      <View style={styles.box}>
          <Image source={require('./assets/S%3Fmbolo_Spin-off_de_sangue.png')} />
          <Text>Você cumpriu um Estigma da Coroa de Espinhos</Text>
          <Text>Retorne a tua forma pristina e deixe o sangue fluir.</Text>
          <Text>Aquele que morrer e depois voltar com 100% de vida terá cumprido sua Intenção.</Text>
      </View>

    </View>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f8ff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  box:{
    backgroundColor: '#ffffff',
    width: '800px',
    height: '500px',
    textAlign: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
