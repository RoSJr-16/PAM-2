import { View, FlatList, StyleSheet, Text, StatusBar } from 'react-native';

const CONTACTS = [
  { id: '1', name: 'Contato 7', subtitle: 'Mensagem...', time: '12:06' },
  { id: '2', name: 'Contato 6', subtitle: 'Mensagem...', time: '12:05' },
  { id: '3', name: 'Contato 5', subtitle: 'Mensagem...', time: '12:04' },
  { id: '4', name: 'Contato 4', subtitle: 'Mensagem...', time: '12:03' },
  { id: '5', name: 'Contato 3', subtitle: 'Mensagem...', time: '12:02' },
];

const ContactItem = ({ name, subtitle, time }) => (
  <View style={styles.row}>
    <View style={styles.avatar}>
      <Text style={styles.avatarText}>{name[0]}</Text>
    </View>

    <View style={styles.info}>
      <Text style={styles.name}>{name}</Text>
      <Text style={styles.subtitle}>{subtitle}</Text>
    </View>

    <Text style={styles.time}>{time}</Text>
  </View>
);

export default function App() {
  return (
    <View style={styles.container}>
      <FlatList
        data={CONTACTS}
        renderItem={({ item }) => (
          <ContactItem
            name={item.name}
            subtitle={item.subtitle}
            time={item.time}
          />
        )}
        keyExtractor={item => item.id}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: StatusBar.currentHeight || 0,
    backgroundColor: '#fff',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#ddd',
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#ccc',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  avatarText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#555',
  },
  info: {
    flex: 1,
  },
  name: {
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 2,
  },
  subtitle: {
    color: '#777',
    fontSize: 14,
  },
  time: {
    fontSize: 12,
    color: '#999',
  },
});